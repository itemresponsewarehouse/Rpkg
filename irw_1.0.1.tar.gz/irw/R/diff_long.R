#' Simulated Item Difficulty Pool from IRW Datasets
#'
#' A dataset of item difficulty estimates and associated standard errors compiled from a curated subset of IRW datasets.
#' Used internally by `irw_simu_diff()` to generate empirically grounded item parameters for simulation.
#'
#' @format A data frame with N rows and 4 variables:
#' \describe{
#'   \item{dataset}{Dataset identifier (character). Indicates the source dataset in IRW.}
#'   \item{item}{Item identifier (character). A label for each item.}
#'   \item{difficulty}{Estimated item difficulty (numeric).}
#'   \item{SE}{Standard error of the difficulty estimate (numeric).}
#' }
#'
#' @details
#' This pool includes binary-response items from IRW datasets that passed basic quality checks—
#' specifically, datasets with less than 50% missing data and without repeated or duplicate responses.
#' It is accessible to users and is used as the default source in `irw_simu_diff()`.
#'
#' @source Curated and compiled by the IRW package authors from selected datasets in the IRW repository.
"diff_long"
