#' List Available Tables
#'
#' Retrieves a summary of available tables in the IRW database, including their name,
#' number of rows, and variable count, sorted alphabetically by table name.
#'
#' @param sim Deprecated. Use \code{source = "sim"} instead.
#' @param comp Deprecated. Use \code{source = "comp"} instead.
#' @param nom Deprecated. Use \code{source = "nom"} instead.
#' @param source Character. Data source: \code{"core"} (default), \code{"nom"}, \code{"sim"}, or \code{"comp"}.
#' @return A data frame with the following columns:
#'   \item{name}{The name of the table, sorted alphabetically.}
#'   \item{numRows}{The number of rows in the table.}
#'   \item{variableCount}{The number of variables in the table.}
#' @examples
#' \dontrun{
#' irw_list_tables()               # Main IRW database
#' irw_list_tables(source = "sim")   # Simulation dataset
#' irw_list_tables(source = "comp")  # Competition dataset
#' }
#' @export
irw_list_tables <- function(source = "core", sim = FALSE, comp = FALSE, nom = FALSE) {
  source <- .irw_resolve_source(source = source, sim = sim, comp = comp, nom = nom)
  ds_list <- .irw_order_datasources(.initialize_datasource(source = source), source = source)

  tables_info_list <- lapply(ds_list, function(ds) {
    tables <- .retry_with_backoff(function() ds$list_tables())
    data.frame(
      name = vapply(tables, function(tbl) tbl$name, character(1)),
      numRows = vapply(tables, function(tbl) tbl$properties$numRows, numeric(1)),
      variableCount = vapply(tables, function(tbl) tbl$properties$variableCount, numeric(1)),
      stringsAsFactors = FALSE
    )
  })
  
  tables_info <- do.call(rbind, tables_info_list)
  tables_info <- .irw_dedup_table_info(tables_info)
  tables_info <- tables_info[order(tables_info$name), ]
  rownames(tables_info) <- NULL
  
  return(tables_info)
}


#' Retrieve and Print IRW Database or Table Information
#'
#' Prints information about the IRW datasets or a specific table.
#'
#' If \code{table_name} is \code{NULL}, shows combined totals across all IRW datasets.
#' Use \code{details = TRUE} to also print a per-dataset breakdown (main IRW only).
#' If a table name is provided, shows details for that table.
#'
#' @param table_name Optional. Table name to describe; if \code{NULL}, prints database‑level info.
#' @param details Logical. When \code{TRUE} and \code{table_name} is \code{NULL}, also
#'   prints a breakdown by dataset. Defaults to \code{FALSE}.
#' @param source Character. Data source: \code{"core"} (default), \code{"nom"}, \code{"sim"}, or \code{"comp"}.
#' @param comp Deprecated. Use \code{source = "comp"} instead.
#' @param sim Deprecated. Use \code{source = "sim"} instead.
#' @param nom Deprecated. Use \code{source = "nom"} instead.
#'
#' @return Invisibly returns \code{NULL}.
#' @examples
#' \dontrun{
#' irw_info()                 # Combined totals
#' irw_info(details = TRUE)   # Combined + per-dataset breakdown
#' irw_info("frac20")      # Specific IRW table
#' irw_info("t20_hyper", source = "comp")  # Competition table
#' irw_info("gilbert_meta_3", source = "sim")
#' 
#' }
#' @export
irw_info <- function(table_name = NULL, details = FALSE, source = "core", comp = FALSE, sim = FALSE, nom = FALSE) {
  if (!is.logical(details) || length(details) != 1) {
    stop("'details' must be a single TRUE or FALSE value.")
  }
  source <- .irw_resolve_source(source = source, sim = sim, comp = comp, nom = nom)

  if (isTRUE(details) && source != "core") {
    stop("details = TRUE is only available for the main IRW datasource (source = \"core\").")
  }

  # label for messages
  db_label <- if (source == "sim") {
    "IRW Simulation Database Information"
  } else if (source == "comp") {
    "IRW Competition Database Information"
  } else if (source == "nom") {
    "IRW Nominal Database Information"
  } else {
    "IRW Database Information (Combined)"
  }

  if (is.null(table_name)) {
    ds_list <- .initialize_datasource(source = source)
    
    total_table_count <- 0
    total_size_gb <- 0
    created_at_all <- c()
    updated_at_all <- c()
    
    for (ds in ds_list) {
      total_table_count <- total_table_count + ds$properties$tableCount
      total_size_gb <- total_size_gb + ds$properties$totalNumBytes / (1024^3)
      created_at_all <- c(created_at_all, ds$properties$createdAt / 1000)
      updated_at_all <- c(updated_at_all, ds$properties$updatedAt / 1000)
    }
    
    message(strrep("-", 50))
    message(db_label)
    message(strrep("-", 50))
    message(sprintf("%-25s %d", "Total Table Count:", total_table_count))
    message(sprintf("%-25s %.2f GB", "Total Data Size:", total_size_gb))
    message(sprintf("%-25s %s", "Earliest Created At:",
                    format(as.POSIXct(min(created_at_all), origin = "1970-01-01", tz = "UTC"),
                           "%Y-%m-%d %H:%M:%S")))
    message(sprintf("%-25s %s", "Latest Updated At:",
                    format(as.POSIXct(max(updated_at_all), origin = "1970-01-01", tz = "UTC"),
                           "%Y-%m-%d %H:%M:%S")))
    message(strrep("-", 50))
    message(sprintf("%-25s %s", "Data Website:", "https://itemresponsewarehouse.org/"))
    message(sprintf("%-25s %s", "Methodology:",
                    "Tables harmonized as per https://itemresponsewarehouse.org/standard.html"))
    message(sprintf("%-25s %s", "Usage Information:",
                    "License & citation info: https://itemresponsewarehouse.org/docs.html"))
    message(strrep("-", 50))
    
    # --- Optional per-dataset details ---
    if (details) {
      for (i in seq_along(ds_list)) {
        ds <- ds_list[[i]]
        message(sprintf("Dataset %d:", i))
        message(sprintf("  %-22s %s", "Version:", ds$properties$version$tag))
        message(sprintf("  %-22s %d", "Table Count:", ds$properties$tableCount))
        message(sprintf("  %-22s %.2f GB", "Total Data Size:",
                        ds$properties$totalNumBytes / (1024^3)))
        message(sprintf("  %-22s %s", "Created At:",
                        format(as.POSIXct(ds$properties$createdAt / 1000,
                                          origin = "1970-01-01", tz = "UTC"),
                               "%Y-%m-%d %H:%M:%S")))
        message(sprintf("  %-22s %s", "Last Updated At:",
                        format(as.POSIXct(ds$properties$updatedAt / 1000,
                                          origin = "1970-01-01", tz = "UTC"),
                               "%Y-%m-%d %H:%M:%S")))
        message(sprintf("  %-22s %s", "Redivis URL:", ds$properties$url))
        message(strrep("-", 50))
      }
    }
  } else {
    # --- Table-specific info ---
    table <- .fetch_redivis_table(table_name, source = source)
    ds_version <- attr(table, "dataset_version")
    
    # Variable names
    vars <- NA
    if (source == "core") {
      m <- .fetch_metadata_table()
      v <- m$variables[m$table == table_name]
      vars <- if (length(v) > 0 && !is.na(v[1]) && nzchar(v[1])) v[1] else NA
    } else {
      # sim / comp / nom: infer from table itself
      vars <- paste(names(table$to_tibble()), collapse = " | ")
    }

    # Tags: only main
    construct <- "Not available for this datasource"
    if (source == "core") {
      construct <- "No construct specified"
      tags <- .fetch_tags_table()
      cvec <- tags$construct_name[tags$table == table_name]
      if (length(cvec) > 0 && !is.na(cvec[1]) && nzchar(cvec[1])) {
        construct <- cvec[1]
      }
    }
    
    # Biblio: main + comp only (sim has none)
    description <- NA
    doi <- NA
    url_data <- NA
    licence <- NA
    reference <- NA
    bib_found <- FALSE
    
    bib <- if (source == "comp") {
      .fetch_comps_biblio_table()
    } else if (source == "sim") {
      .fetch_simsyn_biblio_table()
    } else if (source == "nom") {
      .fetch_nominal_biblio_table()
    } else {
      .fetch_biblio_table()
    }
    
    thisbib <- bib[bib$table == table_name, , drop = FALSE]
    bib_found <- nrow(thisbib) > 0L
    
    if (bib_found) {
      doi <- thisbib$DOI__for_paper_
      url_data <- thisbib$URL__for_data_
      licence <- thisbib$Derived_License
      description <- thisbib$Description
      reference <- thisbib$Reference_x
    }
    
    num_rows <- table$properties$numRows
    data_size <- table$properties$numBytes / 1024
    variable_count <- table$properties$variableCount
    table_url <- table$properties$url
    
    message(strrep("-", 50))
    message("Table Information for: ", table_name,
            if (source == "sim") " (simulation)" else if (source == "comp") " (competition)" else if (source == "nom") " (nominal)" else "")
    message(strrep("-", 50))
    message(strrep("-", 50))
    message(sprintf("%-25s %s", "Description:", description))
    message(sprintf("%-25s %s", "Construct:", construct))
    message(sprintf("%-25s %d", "Number of Rows:", num_rows))
    message(sprintf("%-25s %d", "Variable Count:", variable_count))
    message(sprintf("%-25s %s", "Variables:", vars))
    message(sprintf("%-25s %.2f KB", "Data Size (KB):", data_size))
    message(strrep("-", 50))
    if (!is.null(ds_version) && !is.na(ds_version) && nzchar(ds_version)) {
      message(sprintf("%-25s %s", "Dataset Version:", ds_version))
    }
    message(sprintf("%-25s %s", "Redivis URL:", table_url))
    message(sprintf("%-25s %s", "Data URL:", url_data))
    message(sprintf("%-25s %s", "DOI:", doi))
    message(sprintf("%-25s %s", "License:", licence))
    message(strrep("-", 50))
    message(sprintf("%s%s", "Reference:\n", reference))
    message(strrep("-", 50))
    
    if (!bib_found) {
      message("NOTE: No bibliography row found for this table in the selected source.")
      if (source == "core") {
        message("Hint: If this is a competition / simulation / nominal table, try source = \"comp\", source = \"sim\", or source = \"nom\".")
      }
    }
  }
  
  invisible(NULL)
}
